am start -n com.termux.x11/.MainActivity &&

export DISPLAY=:0

/data/data/com.termux/files/usr/bin/termux-x11 &
