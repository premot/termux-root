#mount -U 6d2ff93e-eacd-415c-96d5-4611ad21e05f /data/local/tmp/pimount
mount /dev/block/mmcblk1p4 /data/local/tmp/pimount
