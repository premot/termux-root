xfce4-terminal
